package bus;

public class Tabungan extends Rekening {
    // Konstanta untuk tingkat bunga Tabungan
    private static final double BUNGA_TABUNGAN = 0.05;

    public Tabungan(String nomorRekening, double saldo) {
        super(nomorRekening, saldo);
    }

    @Override
    public void tambahBunga() {
        saldo += saldo * BUNGA_TABUNGAN;
    }

    @Override
    public double hitungBungaSaldo() {
        return getSaldo() * BUNGA_TABUNGAN;
    }
}