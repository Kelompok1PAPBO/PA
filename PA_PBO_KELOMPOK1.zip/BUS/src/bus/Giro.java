package bus;

public class Giro extends Rekening {
    // Konstanta untuk tingkat bunga Giro
    private final double BUNGA_GIRO = 0.01;

    public Giro(String nomorRekening, double saldo) {
        super(nomorRekening, saldo);
    }

    @Override
    public void tambahBunga() {
        saldo += saldo * BUNGA_GIRO;
    }

    @Override
    public double hitungBungaSaldo() {
        return getSaldo() * BUNGA_GIRO;
    }
}