package bus;
import java.sql.SQLException;
public class Rekening extends Database {
    
    public String getNomorRekening() {
        return nomorRekening;
    }

    public void setNomorRekening(String nomorRekening) {
        this.nomorRekening = nomorRekening;
    }

    public double getSaldo() {
        return saldo;
    }

    public void setSaldo(double saldo) {
        this.saldo = saldo;
    }
    private String nomorRekening;
    double saldo;
    
    public Rekening(String nomorRekening, double saldo) {
        this.nomorRekening = nomorRekening;
        this.saldo = saldo;
    }
    public void tambahBunga() {
}
    public double hitungBungaSaldo() {
        return 0.0;
        
    }
     public void tambahSaldo(double jumlah) {
        if (jumlah > 0) {
            saldo += jumlah;
            System.out.println("Saldo berhasil ditambahkan. Saldo terkini: " + saldo);
        } else {
            System.out.println("Jumlah setoran tidak valid.");
        }
    }
public void tambahSaldoDatabase(double jumlahSetoran, int nasabahId) {
        try {
            // Buka koneksi ke database
            openConnection();

            // Lakukan update pada tabel rekening (sesuai dengan struktur tabel Anda)
            String sql = "UPDATE rekening SET saldo = saldo + ? WHERE nasabah_id_nasabah = ?";
            preparedStatement = connection.prepareStatement(sql);
            preparedStatement.setDouble(1, jumlahSetoran);
            preparedStatement.setInt(2, nasabahId);

            // Eksekusi query
            int result = preparedStatement.executeUpdate();

            if (result > 0) {
                System.out.println("Data saldo berhasil diperbarui di database.");
            } else {
                System.out.println("Gagal memperbarui data saldo di database.");
            }
        } catch (SQLException ex) {
            displayErrors(ex);
        } finally {
            closeConnection();
        }
    }
}