package bus;

import java.sql.Statement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.sql.ResultSet;
import java.util.Random;

public class Nasabah extends Database{
    private List<Rekening> rekeningList;
    public List<Rekening> getRekeningList() {
    return rekeningList;
    }
 private final String generateNomorRekening() {
        int length = 10;
        StringBuilder sb = new StringBuilder();

        // Gunakan kelas Random untuk menghasilkan digit acak
        Random random = new Random();
        for (int i = 0; i < length; i++) {
            int digit = random.nextInt(10); // Angka 0-9
            sb.append(digit);
        }

        return sb.toString();
}
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNama() {
        return nama;
    }

    public void setNama(String nama) {
        this.nama = nama;
    }

    public String getAlamat() {
        return alamat;
    }

    public void setAlamat(String alamat) {
        this.alamat = alamat;
    }

    public String getNomorTelpon() {
        return nomorTelpon;
    }

    public void setNomorTelpon(String nomorTelpon) {
        this.nomorTelpon = nomorTelpon;
    }

    public String getPin() {
        return pin;
    }

    public void setPin(String pin) {
        this.pin = pin;
    }
    
    public String getJenisrekening() {
        return jenisrekening;
    }

    public void setJenisrekening(String jenisrekening) {
        this.jenisrekening = jenisrekening;
    }

    private int id;
    public String nama;
    public String alamat;
    public String nomorTelpon;
    public String pin;
    public String jenisrekening;
  
        public Nasabah(int id, String nama, String alamat, String nomorTelpon, String pin,String jenisrekening) {
        this.id = id;
        this.nama = nama;
        this.alamat = alamat;
        this.nomorTelpon = nomorTelpon;
        this.pin = pin;
        this.jenisrekening = jenisrekening;
        rekeningList = new ArrayList<>();
        initRekeningListFromDatabase(id);
    }
//    public boolean create() {
//        boolean isOperationSuccess = false;
//        
//        try {
//            this.openConnection();
//            
//            String sql = "INSERT INTO nasabah VALUES (null, ?, ?, ?,?)";
//            this.preparedStatement = this.connection.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
//            
//            this.preparedStatement.setString(1, this.nama);
//            this.preparedStatement.setString(2, this.alamat);
//            this.preparedStatement.setString(3, this.nomorTelpon);
//            this.preparedStatement.setString(4, this.pin);
//            
//            int result = this.preparedStatement.executeUpdate();
//            this.id = this.generateLastId();
//           
//            
//            isOperationSuccess = result > 0;
//        } catch (SQLException ex) {
//            this.displayErrors(ex);
//        } finally {
//            this.closeConnection();
//        }
//        
//        return isOperationSuccess;
//    }
        public boolean create() {
    boolean isOperationSuccess = false;

    try {
        this.openConnection();

        // Menyisipkan data nasabah ke dalam tabel nasabah
        String sqlNasabah = "INSERT INTO nasabah VALUES (null, ?, ?, ?, ?,?)";
        this.preparedStatement = this.connection.prepareStatement(sqlNasabah, Statement.RETURN_GENERATED_KEYS);

        this.preparedStatement.setString(1, this.nama);
        this.preparedStatement.setString(2, this.alamat);
        this.preparedStatement.setString(3, this.nomorTelpon);
        this.preparedStatement.setString(4, this.pin);
        this.preparedStatement.setString(5, jenisrekening); 
        int resultNasabah = this.preparedStatement.executeUpdate();
        if (resultNasabah > 0) {
            // Jika penyisipan data nasabah berhasil, ambil ID yang baru dibuat
            ResultSet generatedKeys = this.preparedStatement.getGeneratedKeys();
            if (generatedKeys.next()) {
                this.id = generatedKeys.getInt(1);

                // Menambahkan rekening baru ke dalam tabel rekening
                String nomorRekening = generateNomorRekening(); // Ganti ini dengan metode pembuatan nomor rekening Anda
                double saldoAwal = 50000; // Ganti ini dengan saldo awal yang diinginkan

                String sqlRekening = "INSERT INTO rekening VALUES (?, ?, ?)";
                this.preparedStatement = this.connection.prepareStatement(sqlRekening);
                this.preparedStatement.setString(1, nomorRekening);
                this.preparedStatement.setDouble(2, saldoAwal);
                this.preparedStatement.setInt(3, this.id); // Menggunakan ID nasabah yang baru dibuat

                int resultRekening = this.preparedStatement.executeUpdate();

                isOperationSuccess = resultRekening > 0;
            }
        }
    } catch (SQLException ex) {
        this.displayErrors(ex);
    } finally {
        this.closeConnection();
    }

    return isOperationSuccess;
}
    

        public boolean update() {
        boolean isOperationSuccess = false;

        try {
            this.openConnection();

            String sql = "UPDATE nasabah "
                    + "SET pin = ? "
                    + "WHERE id_nasabah = ?";

            this.preparedStatement = this.connection.prepareStatement(sql);

            this.preparedStatement.setString(1, this.pin);
            this.preparedStatement.setInt(2, this.id);

            int result = this.preparedStatement.executeUpdate();

            isOperationSuccess = result > 0;
        } catch (SQLException ex) {
            this.displayErrors(ex);
        } finally {
            this.closeConnection();
        }

        return isOperationSuccess;
    }
public boolean login(String username, String password) {
    boolean isValid = false;
    openConnection();

    try {
        String query = "SELECT * FROM nasabah WHERE nama = ? AND pin = ?";
        this.preparedStatement = this.connection.prepareStatement(query);
        preparedStatement.setString(1, username);
        preparedStatement.setString(2, password);

        this.resultSet = this.preparedStatement.executeQuery();
        if (resultSet.next()) {
            // Fetch user details
            this.id = resultSet.getInt("id_nasabah");
            this.nama = resultSet.getString("nama");
            this.alamat = resultSet.getString("alamat");
            this.nomorTelpon = resultSet.getString("nomor_telpon");
            this.pin = resultSet.getString("pin");
            this.jenisrekening = resultSet.getString("jenis_rekening");

            isValid = true;
        }

    } catch (SQLException ex) {
        displayErrors(ex);
    } finally {
        closeConnection();
    }

    return isValid;
}
    public boolean updatePin(String newPin) {
        setPin(newPin); // Set PIN baru pada objek Nasabah

        boolean isUpdateSuccess = update(); // Panggil metode update() dari kelas Nasabah

        if (isUpdateSuccess) {
            // Lakukan tindakan tambahan jika update berhasil
        } else {
            // Lakukan tindakan tambahan jika update gagal
        }

        return isUpdateSuccess;
    }
    private void initRekeningListFromDatabase(int idNasabah) {
        try {
            openConnection();
            String query = "SELECT * FROM rekening WHERE nasabah_id_nasabah = ?";
            preparedStatement = connection.prepareStatement(query);
            preparedStatement.setInt(1, idNasabah);

            resultSet = preparedStatement.executeQuery();
            while (resultSet.next()) {
                String nomorRekening = resultSet.getString("nomor_rekening");
                double saldo = resultSet.getDouble("saldo");

                Rekening rekening = new Rekening(nomorRekening, saldo);
                rekeningList.add(rekening);
            }
        } catch (SQLException ex) {
            displayErrors(ex);
        } finally {
            closeConnection();
        }
    }
    public boolean deleteAccount() {
        boolean isOperationSuccess = false;

        try {
            openConnection();

            // Hapus rekening terlebih dahulu
            String deleteRekeningQuery = "DELETE FROM rekening WHERE nasabah_id_nasabah = ?";
            preparedStatement = connection.prepareStatement(deleteRekeningQuery);
            preparedStatement.setInt(1, this.id);

            int rekeningResult = preparedStatement.executeUpdate();

            // Hapus akun nasabah setelah rekening dihapus
            if (rekeningResult > 0) {
                String deleteNasabahQuery = "DELETE FROM nasabah WHERE id_nasabah = ?";
                preparedStatement = connection.prepareStatement(deleteNasabahQuery);
                preparedStatement.setInt(1, this.id);

                int nasabahResult = preparedStatement.executeUpdate();

                isOperationSuccess = nasabahResult > 0;
            }
        } catch (SQLException ex) {
            displayErrors(ex);
        } finally {
            closeConnection();
        }

        return isOperationSuccess;
    }
}

